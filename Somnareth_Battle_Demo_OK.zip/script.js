
function attack() {
    document.getElementById('log').innerText = "¡Vayn ataca al Eco Salvaje!";
}
function magic() {
    document.getElementById('log').innerText = "¡Vayn lanza magia!";
}
